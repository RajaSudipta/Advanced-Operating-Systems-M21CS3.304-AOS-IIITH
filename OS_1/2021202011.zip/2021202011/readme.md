# Terminal Based File Explorer.

# Implemented two modes. Normal Mode and Command Mode.

## As per assignment, I have not shown result of any command except 'search' in command mode. The result is shown in next iteration of command mode. We can clear the output and run the next query. For eg. if the search result returns true, it will be displayed like 'Command Mode: true'. We can clear this true part and run the next query.
